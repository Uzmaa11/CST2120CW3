//Import the express and body-parser modules
const express = require('express');
const bodyParser = require('body-parser');
const expressSession =require('express-session');
const mysql = require('mysql');

//Import database functions
const db = require('./database');

//Create express app and configure it with body-parser
const app = express();
app.use(bodyParser.json());

//Set up express to serve static files from the directory called 'public'
app.use(express.static('public'));

//configure express to use express-session
app.use(
    expressSession({
        secret:'cst 2120 secret',
        cookie:{maxAge:60000},
        resave:false,
        saveUninitialized:true
    })
);

//Set up application to handle GET requests sent to the users path
app.get('/logout', logout);//Logs user out
app.get('/recipes',getRecipes);//displays recipes

//Set up application to handle POST requests sent to the customers path
app.post('/register', register);//Adds a new user
app.post('/addrecipe', AddRecipe);//Adds a new recipe
app.post('/login', login);//Logs the user in


//Start the app listening on port 8080
app.listen(8080);
console.log("Listening on port 8080");
//Handles POST requests to our web service
function register(request, response){
    //Extract user data
    let newCust = request.body;
    console.log("Data received: " + JSON.stringify(newCust));

    //Call function to add new user
    db.addUser(newCust.name, newCust.DateOfBirth, newCust.email, newCust.address, newCust.password, response);
}
//Handles POST requests to our web service
function AddRecipe(request, response){
    //Extract recipe data
    let newRec = request.body;
    console.log("Data received: " + JSON.stringify(newRec));  

    //Call function to add new recipe
    db.addRecipe(newRec.title,newRec.image,newRec.category,newRec.description,newRec.ingredients,newRec.duration,newRec.directions, response);
}
/* POST /login. Checks the user's email and password. Logs them in if they match */
function login(request, response){
    let usrlogin = request.body;
    UserLogin(); 
    async function UserLogin(){
        const connectionPool = mysql.createPool({
            connectionLimit: 1,
            host: "localhost",
            user: "uzma",
            password: "123456",
            database: "sugarrush",
            debug: false
        });

        //build query
        let sql=" SELECT * FROM user WHERE email='"+usrlogin.email+"' && password='"+usrlogin.password+"';" ;
            
        //Wrap the execution of the query in a promise
        let selectPromise = new Promise ( (resolve, reject) => { 
            connectionPool.query(sql, (err, result) => {
                if (err){//Check for errors
                    reject("Error executing query: " + JSON.stringify(err));
                }
                else{//Resolve promise with results
                    resolve(result);
                }
            });
        });
        try{
            //Execute promise and output result
            let logUser = await selectPromise;
            let loggedUser=JSON.stringify(logUser);
    
             if (loggedUser =="[]"){
                response.send("false");
             }
            else{
                request.session.username=logUser[0].ID;
                let ID=request.session.username;
                response.send('[{"login":"ok","username":"'+ID+'"}]');
            }
        }
        catch(err){
            console.error(JSON.stringify(err));
        }
    }
    
}
// GET /logout. Logs the user out.
function logout(request, response){
    //Destroy session.
    request.session.destroy( err => {
        if(err)
            response.send('{"error": '+ JSON.stringify(err) + '}');
        else
            response.send("UserLogout");
    });
}
//GET /recipes. retrieves the recipes from database and displays them
function getRecipes(request,response){
    //split the path of request into its components
    var pathArray=request.url.split("/");
    var pathEnd=pathArray[pathArray.length-1];

    if(pathEnd === 'recipes'){
        db.getAllRecipes(response);
    }
else{
    response.send("{error:'Path not recognized'}")
}      
}
//Export server for testing
module.exports = app;