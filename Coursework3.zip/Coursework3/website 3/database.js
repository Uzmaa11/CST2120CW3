//Import the mysql module and create a connection pool with user details
const mysql = require('mysql');
const connectionPool = mysql.createPool({
    connectionLimit: 1,
    host: "localhost",
    user: "uzma",
    password: "123456",
    database: "sugarrush",
    debug: false
});
//Adds a new user to database 
exports.addUser = (name,DateOfBirth, email, address, password, response) => {
    //Build query
    let sql = "INSERT INTO user (name, DateOfBirth, email, address, password) " +
"VALUES ('" + name + "','" + DateOfBirth + "','" + email + "','" + address + "','" + password +"')";
    //Execute query
    connectionPool.query(sql, (err, result) => {
        if (err){//Check for errors
            let errMsg = "{Error: " + err + "}";
            console.error(errMsg);
            response.status(400).json(errMsg);
        }
        else{//Send back result
            response.send("{result: 'You are successfully registered!'}");
        }
    });
}
//Adds a new recipe to database 
exports.addRecipe = (title,image,category,description,ingredients,duration,directions,response) => {
    //Build query
    let sql = "INSERT INTO recipe (title,image,category,description,ingredients,duration,directions) " +
"VALUES ('" + title + "','" + image + "','"  +category + "','" + description +"','" + ingredients +"','" + duration +"','" + directions +"')";
    //Execute query
    connectionPool.query(sql, (err, result) => {
        if (err){//Check for errors
            let errMsg = "{Error: " + err + "}";
            console.error(errMsg);
            response.status(400).json(errMsg);
        }
        else{//Send back result
            response.send("ok");
        }
    });
}
//displays all recipes
exports.getAllRecipes = (response) => {
    //Build query
    let sql = "SELECT * FROM recipe ";

    //Execute query
    connectionPool.query(sql, (err, result) => {
        if (err){//Check for errors
            let errMsg = "{Error: " + err + "}";
            console.error(errMsg);
            response.status(400).json(errMsg);
        }
        else{//Return result in json format
            response.send(JSON.stringify(result))

        }
    });
};
