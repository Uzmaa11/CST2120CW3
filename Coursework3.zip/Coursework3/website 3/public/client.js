//handles registration
function addUser(){
  //set up XMLHttpRequest  
    let xhttp=new XMLHttpRequest();
    //Extract user data
    let usrName=document.getElementById("NameInput").value;
    let usrDate=document.getElementById("DOBInput").value;
    let usrEmail=document.getElementById("EmailInput").value;
    let usrAddress=document.getElementById("AddressInput").value;
    let usrPassword=document.getElementById("PasswordInput").value;
    
    //Create object with user data
    let usrObj ={
        name:usrName,
        DateOfBirth: usrDate,
        email:usrEmail,
        address:usrAddress,
        password:usrPassword
            };
    //Set up function that is called when reply is recieved from server
    xhttp.onreadystatechange=function(){
        if(this.readyState ==4 && this.status ==200){
           if(xhttp.responseText=="{result: 'You are successfully registered!'}") {
               document.getElementById("AddUserResult").innerHTML="You have been successfully registered!";
           }
            }
        else{
            document.getElementById("AddUserResult").innerHTML="<span style='color: red'>Unsuccessful registration!</span>";
        }
    };
    //Send new user data to server
    xhttp.open("POST","/register",true);
    xhttp.setRequestHeader("Content-type","application/json");
    xhttp.send(JSON.stringify(usrObj));    

    return false;
}
//handles login functionality
function SignInUser(){
    //set up XMLHttpRequest  
    let xhttp=new XMLHttpRequest();
    //Extract user data
    let email=document.getElementById("EmailInput1").value;
    let password=document.getElementById("PasswordInput01").value;

    //Create object with user data
    let usrObj ={
    email:email,
    password:password
    };

//Set up function that is called when reply is recieved from server
xhttp.onreadystatechange=function(){
    
    if(this.readyState ==4 && this.status ==200){
        if (xhttp.responseText=="false"){
            document.getElementById("LogUserResult").innerHTML="<span style='color: red'>Login unsuccessful!</span>";
        }
    }
    else{
        document.getElementById("LogUserResult").innerHTML="You have logged in successfully!";
        console.log(xhttp.responseText);
        let usrArr=JSON.parse(xhttp.responseText);
        let loggedUserId=usrArr[0].username;
        console.log(loggedUserId);
        document.getElementById("addRecipeForm").style.visibility="visible";
        document.getElementById("addRecipeForm").style.display="block";
    }
    
};
//Send logged in user data to server
xhttp.open("POST","/login",true);
xhttp.setRequestHeader("Content-type","application/json");
xhttp.send(JSON.stringify(usrObj)); 

return false;
}
//handles recipe uploading
function addRecipe(){
    //set up XMLHttpRequest  
      let xhttp=new XMLHttpRequest();
      
      //Extract user data
      let usrTitle=document.getElementById("TitleInput").value;
      let usrImage=document.getElementById("ImageInput").value;
      let usrCategory=document.getElementById("CategoryInput").value;
      let usrDescription=document.getElementById("DescriptionInput").value;
      let usrIngredients=document.getElementById("IngredientsInput").value;
      let usrDuration=document.getElementById("DurationInput").value;
      let usrDirections=document.getElementById("DirectionsInput").value;
      
      //Create object with user data
      let usrRecipe ={
          title:usrTitle,
          image:usrImage,
          category:usrCategory,
          description:usrDescription,
          ingredients:usrIngredients,
          duration:usrDuration,
          directions:usrDirections
              };
      //Set up function that is called when reply is recieved from server
      xhttp.onreadystatechange=function(){
          if(this.readyState ==4 && this.status ==200){
                document.getElementById("AddRecipeResult").innerHTML="Recipe uploaded successfully!";
              }
          else{
              document.getElementById("AddRecipeResult").innerHTML="<span style='color: red'>Unsuccessful upload!</span>";

          }
      };
      //Send new recipe data to server
      xhttp.open("POST","/addrecipe",true);
      xhttp.setRequestHeader("Content-type","application/json");
      xhttp.send(JSON.stringify(usrRecipe));    
  
      return false;
  }
  //handles log out functionality
function SignOutUser(){
    //set up XMLHttpRequest  
    let xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=()=>{//called when data returns from server
        if(xhttp.readyState==4 && xhttp.status==200){
        if(xhttp.responseText=="UserLogout"){
           document.getElementById("LogUserResult").innerHTML="You have logged out successfully!";
           document.getElementById("addRecipeForm").style.visibility="hidden";
           document.getElementById("addRecipeForm").style.display="none";
        }
        else {document.getElementById("LogUserResult").innerHTML="Log out unsuccessful!" +xhttp.responseText;}
        }
    };
    //Request data for all customers
    xhttp.open("GET","/logout",true);
    xhttp.send();
    return false;
}
window.onload = loadRecipes;         
 //Downloads JSON description of products from server
function loadRecipes(){
    //Create request object 
    let xhttp = new XMLHttpRequest();
xhttp.onreadystatechange=()=>{
    if (xhttp.readyState ==4 && xhttp.status==200)
    {
        let usrArr=JSON.parse(xhttp.responseText);
        if(usrArr.length===0)
        return;

    let htmlStr="";
    for(let i=0; i<usrArr.length; ++i){
    htmlStr += '<div  id="grid-container">';
    htmlStr += '<div>';
    htmlStr += '<img id="imageid" width=600px height=500px src="'+usrArr[i].image+'">';  
    htmlStr += '<div height=500px width=600px class="container">';
    htmlStr += '<div class="recipetitle">';
    htmlStr += '<h3>'+ usrArr[i].title+'</h3>';
    htmlStr += '</div>';
    htmlStr += '<div class="recipedescription">';
    htmlStr += '<div>'+ usrArr[i].description+'</div>';
    htmlStr += '</div>';
    htmlStr += '<div class="recipeingredient">';
    htmlStr += '<h4>Ingredients:'+ usrArr[i].ingredients+'</h4>';
    htmlStr += '</div>';
    htmlStr += '<div class="recipedirection">';
    htmlStr += '<h5>Directions:'+ usrArr[i].directions+'</h5>';
    htmlStr += '</div>';
    htmlStr += '<div class="recipeduration">';
    htmlStr += '<h5>Duration:'+ usrArr[i].duration+'</h5>';
    htmlStr += '</div>';
    htmlStr += '</div>';   
    htmlStr += '</div>';
    htmlStr += '</div>';
}
document.getElementById("RecipeDiv").innerHTML+=htmlStr;

    }
};
    //Set up request and send it
    xhttp.open("GET","/recipes",true);
    xhttp.send();
}          
var slideIndex = 1;
showSlides(slideIndex);
//helps in adding slides
function plusSlides(n) {
  showSlides(slideIndex += n);
}
//displays current slide
function currentSlide(n) {
  showSlides(slideIndex = n);
}
//displays slides
function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  slides[slideIndex-1].style.display = "block"; 
   
} 
//validates the registration form
function check() {
  if (document.getElementById('PasswordInput').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('AddUserResult').style.color = 'green';
    document.getElementById('AddUserResult').innerHTML = 'You can proceed to register!';
    document.getElementById('registernow').disabled=false;
  } else {
     document.getElementById('registernow').disabled=true;
    document.getElementById('AddUserResult').style.color = 'red';
    document.getElementById('AddUserResult').innerHTML = 'The passwords do not match!';
  }
} 