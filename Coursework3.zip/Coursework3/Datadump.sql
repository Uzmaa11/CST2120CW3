-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.8-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for sugarrush
CREATE DATABASE IF NOT EXISTS `sugarrush` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `sugarrush`;

-- Dumping structure for table sugarrush.recipe
CREATE TABLE IF NOT EXISTS `recipe` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` char(50) DEFAULT NULL,
  `image` char(50) DEFAULT NULL,
  `category` char(50) DEFAULT NULL,
  `description` varchar(5100) DEFAULT NULL,
  `ingredients` varchar(5000) DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `directions` varchar(6000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table sugarrush.recipe: ~2 rows (approximately)
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` (`ID`, `title`, `image`, `category`, `description`, `ingredients`, `duration`, `directions`) VALUES
	(2, 'Pastel Macaroons', 'images/h4.jpg', 'Macaroons', 'A Classic French macaroon with vanilla buttercream', '1¾ cups powdered sugar, 1 cup almond flour, 1 teaspoon salt, 3 egg whites, ½ teaspoon vanilla extract,2 drops food coloring, 1 cup vanilla butter cream', '120mins', '1-Mix the powdered sugar, almond flour, and ½ teaspoon salt in a bowl. 2-Beat the egg whites and vanilla syrup in another bowl until you notice stiff peaks.3-Add food coloring. 4-Pipe the mixture and form circles on the parchment paper. 5-Bake at 300F for 20 minutes. 6-Fill with vanilla butter cream and Enjoy!'),
	(28, 'Unicorn Milkshake', 'images/hh.jpg', 'Shakes', 'Strawberry flavored milkshake with marshmallow creme', '1/4 cup milk, 1/4 cup marshmallow creme, 1 cup strawberry flavored syrup, 3 cups vanilla icecream ,1 cup strawberries, rainbow sprinkles and marshmallows', '20 mins', '1. Mix the 1 cup strawberry syrup in 1/4 cup milk. 2-Pour the shake and 1/4 cup of marshmallow creme in a glass. 3-Add the 3 cups of vanilla icecream or any icecream of your choice at the top. 4- Sprinkle some rainbow sprinkles and marshmallows as toppings on the glass. Enjoy!');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;

-- Dumping structure for table sugarrush.user
CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table sugarrush.user: ~6 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`ID`, `name`, `DateOfBirth`, `address`, `email`, `password`) VALUES
	(1, 'uzma', '2001-09-11', 'new jersey street', 'uzma@gmail.com', 'uzma'),
	(2, 'niall', '1991-09-13', 'central park street', 'niall@gmail.com', 'niall'),
	(3, 'liam', '1991-08-29', 'xiang hua street', 'liam@gmail.com', 'liam'),
	(4, 'chris', '1991-06-21', 'central square street', 'chris@gmail.com', 'chris'),
	(5, 'louis', '2001-02-04', 'new yorker street', 'louis@gmail.com', 'louis');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
